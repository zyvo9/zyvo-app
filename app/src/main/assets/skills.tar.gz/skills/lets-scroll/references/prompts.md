# Prompt templates & intake

Everything here is fill-in-the-slots. Keep the **style preamble** byte-for-byte identical
across all scene stills — that identical text is what makes the world feel like one place.

## Intake checklist (Step 1)

Collect and write down:

- `SUBJECT` — the business + one-line pitch.
- `BRAND_NAME` — display name.
- `PALETTE` — 4–6 named hexes, e.g. `taro #9B7EBD, cream #F5EDE0, caramel #C88A5A, matcha #8FB98A, plum #3A2E48`. Pick ONE as the scene **background** colour (usually the lightest) and one as the primary **accent**.
- `TONE` — a word or two (cozy/premium, playful, industrial…).
- `STYLE` — the art direction (default below).
- `SECTIONS[]` — ordered list; for each: `id`, `label`, `subject` (what's in the diorama), `eyebrow`, `title`, `body` (≤ 1 sentence), `tags[]` (0–3). Last section = hero product + CTA.
- `N` — scene count: 2 (teaser: opener + hero/CTA) | 4 (short journey) | 6 (full
  film — **maximum**). **Always asked** (SKILL Step 1.5) before proposing the section
  list. Assets = N stills + (2N−1) clips.
- `CAMERA` — fly-through (arch B: dives + aerial hops — the flagship-demo look) |
  walkthrough (arch A: one continuous forward flight) | locked-iso (arch A + the
  locked-iso clause below: one fixed angle for the whole film). **Always asked**
  (SKILL Step 1.4), presented by feel with a one-line trade-off each.
- `MOBILE` — yes/no. **Always asked** (SKILL Step 1.6), presented to the user
  with the ~2× credit cost stated. Yes = the **native 9:16 portrait chain**
  (pipeline §6b): portrait renders of every dive/connector +
  `clipMobile`/`connectorsMobile`/`stillMobile` wiring + the full mobile QA. The
  §6 crop encodes are a no-credits stopgap only.
- `ASSET_SOURCE` — automatic (the skill renders: Higgsfield/Codex stills,
  Monid/Higgsfield video) | manual (the skill writes every prompt file + the
  conditioning frames; the user renders in tools of their choice and drops the
  finished files into `$WORK`). **Always asked** (SKILL Step 1.7). On the manual
  path `VIDEO_TIER`/`STILLS_SOURCE` below don't apply — but the user's video tool
  must accept a start frame (and, for arch B connectors, an end frame).
- `VIDEO_TIER` — (automatic path only) default is `seedance_2_0` **via Monid**
  (pay-per-clip; previz = same endpoint at 480p, final at 1080p).
  Higgsfield-credit alternates: draft (`seedance_2_0_mini`) | standard
  (`seedance_2_0`) | alternate (`kling3_0`). Chosen by cost at SKILL Step 1.8,
  with the estimated total stated before anything renders.
- `STILLS_SOURCE` — (automatic path only) higgsfield (`gpt_image_2`, spends
  credits) | codex (`image_gen`, subscription-billed; only offer when the Codex
  CLI is present).

## Style preamble (default: clay diorama)

Reuse verbatim in every scene prompt. Swap the bracketed bits for the brand's palette/bg.

```
Isometric low-poly 3D diorama floating as a small rounded island on a plain solid
[BG_HEX] background with a soft contact shadow beneath it. Soft matte clay 3D render,
rounded toy-model shapes, gentle warm studio lighting, soft long shadows, tilt-shift
miniature look. Cohesive color palette of [PALETTE]. Highly detailed, centered
composition, absolutely no text, no letters, no numbers, no logos.
```

Alternate directions (swap the first two sentences, keep the palette/no-text tail):
- **Flat papercraft:** "Isometric layered paper-craft diorama, matte cardstock, clean die-cut edges, subtle drop shadows between layers."
- **Glossy toy:** "Isometric glossy vinyl-toy diorama, smooth plastic shading, soft rim light, collectible figurine look."
- **Claymation:** "Isometric stop-motion clay set, visible thumbprints, handmade plasticine texture, soft studio softbox light."
- **Neon night:** "Isometric miniature at night, warm interior glow and neon signage, moody rim light, wet reflective ground."
- **Photoreal architectural** (real estate, hospitality, premium/luxury): "Ultra-photorealistic architectural photography of a single cohesive [subject], cinematic wide-angle, warm golden-hour light, natural materials, restrained designer furnishings, a breathtaking view, editorial magazine quality (Architectural Digest), shallow depth of field, no people." For photoreal, drop the floating-island framing and the knockout (Step 3) — the scenes are **full-bleed** (a dark page background reads premium), the "dive" glides *through doorways/glass* rather than opening a roof, and cohesion comes entirely from the identical preamble (do NOT pass an `--image` reference — it clones the same room). Interiors trip Seedance's NSFW filter often; see SKILL Gotchas.

## Scene still prompt (Step 2)

Every prompt must be **fully self-contained**: on the manual path each still may be
rendered in a different tool or session, so the aspect ratio, the background lock and
the palette must live IN THE PROMPT TEXT — never rely on tool-side settings you can't
guarantee, and never strip these lines when adapting the template.

```
[STYLE PREAMBLE]
Render a wide 3:2 landscape image, at least 1536 px wide. The background stays a plain
solid [BG_HEX] across the whole frame — a completely empty backdrop: no sky, no clouds,
no horizon, no gradient. Centered composition with a little headroom; the focal subject
horizontally centred and nothing essential at the far left/right edges. Absolutely no
text, no letters, no numbers, no logos.
Subject: [SECTION.subject — describe the miniature scene: the building/space, a few
characters doing the work, the props that signal this stage of the business].
```

Tips:
- Name concrete props (they anchor the scene): tanks, cauldrons, conveyor, crates, awning, string lights, benches, scooters, map pins.
- For the final "hero product" section, drop the diorama-island framing and prompt a
  single oversized product centerpiece floating on the same background with a few small
  orbiting props.
- **Compose for the centre.** The page renders every clip `object-fit:cover`. Keep the
  focal subject horizontally centred with a little headroom, and don't park anything
  essential at the far left/right edges. Mobile ships its own native 9:16 chain
  (pipeline §6b), so this is not about surviving a crop — but a centred composition makes
  the portrait renders open cleanly from the same still, and it keeps the dive's focal
  point where the camera actually flies.
- Automatic-path CLI flags: `--aspect_ratio 3:2 --resolution 2k --quality high`. The
  prompt's own 3:2 + background-lock sentences still do the consistency work whenever a
  still is rendered outside that CLI (manual path, another tool, a re-roll elsewhere).

## Leg prompt — architecture A, continuous forward take (Step 4)

`--start-image = previous leg's ACTUAL last frame` (leg 0: the first scene's still).
**No `--end-image`.** The bolded clauses are the motion-handoff contract — keep them
verbatim; the mid-leg move is where the expression goes.

```
Single continuous cinematic camera move, no cuts. **Continue the same slow, steady
forward glide.** [MID-LEG MOVE — optional, from the library below.] The camera moves
into [SCENE i] toward [FOCAL POINT]. **In the final second, settle back into a slow,
steady forward glide toward [the doorway / opening / direction of the next scene].**
[STYLE tail + PALETTE]. Smooth, graceful, slow motion, subtle parallax. No text, no captions.
```

### Mid-leg move library (pick by concept; omit for a plain glide)

Reversals are safe *inside* a leg (it's one continuous render) — only a seam may never
reverse. That's why "ease back out" is fine mid-leg.

**Locked-iso clause** (`CAMERA` = locked isometric glide — SKILL Step 1.4/Step 4):
skip this library entirely and put this clause, verbatim, in the mid-leg slot of
EVERY leg:

```
The camera keeps exactly the same high isometric angle throughout — no rotation, no
orbit, no tilt. It only travels straight and level, the world sliding past beneath
the same view.
```

Keep the handoff-contract clauses around it unchanged. When checking each leg's last
frame, also check the ANGLE hasn't drifted (Seedance rotates slightly on long legs) —
re-roll the leg if the view has turned.

- **Half-orbit** (product, luxury): "sweeping in a slow half-orbit around [the hero
  object], keeping it centered, then continuing past it"
- **Crane-up reveal** (scale, atriums, campuses): "rising smoothly as the full scale of
  [the space] reveals below"
- **Low lateral track** (production lines, counters, shelves): "tracking low and level
  alongside [the line], foreground objects sliding past in parallax"
- **Push-in + ease back** (craft, detail): "pushing in close to [the craft moment] until
  it nearly fills the frame, then easing gently back out"
- **Rise-and-swoop** (travel, outdoors): "climbing in a gentle arc over [the terrain],
  then swooping down toward [the next focal point]"

After rendering each leg, **check its last frame** before generating the next: it should
read as a frame from a calm forward glide (no motion blur sideways, no half-finished
orbit). If it doesn't, re-roll this leg — a bad handoff frame poisons every leg after it.

## Dive-in clip prompt (Step 4)

`--start-image = the scene still` (solid-bg version).

```
Single continuous cinematic camera move, no cuts. Begin high and far, looking down at the
whole [SECTION.subject] from outside like a tiny model. The camera slowly glides forward
and descends toward it, sweeping in toward [FOCAL POINT — the counter/the cauldrons/the
people], as if flying inside. As the camera pushes in, the roof and upper structure
gently lift and open away to reveal the warm interior. The backdrop stays a plain solid
[BG_HEX] the whole time — completely empty, no sky, no clouds, no horizon, no ground.
[STYLE tail: soft matte clay diorama, tilt-shift miniature, warm light, [PALETTE]].
Smooth, graceful, slow motion, subtle parallax. No text, no captions.
```

For scenes with no building to open (a field, a plaza, a road), replace the roof clause
with "the camera flies low across [the scene] toward [focal point]."

Params by chain model (SKILL Step 4 table): seedance —
`--mode std --resolution 1080p --aspect_ratio 16:9 --duration 8`, no audio flag;
kling3_0 — `--mode std --sound off --aspect_ratio 16:9 --duration 10` (no `--resolution`
param). Same for architecture-A legs.

## Connector clip prompt (Step 5)

`--start-image = dive_i LAST frame` (extracted), `--end-image = dive_{i+1} FIRST frame`
(extracted). Both from the RENDERED videos, not the stills.

```
Single continuous cinematic camera move, no cuts. The camera smoothly pulls up and back
out of [SCENE i], rising into the sky, then glides forward across the connected miniature
world and arrives above [SCENE i+1], beginning to descend toward it. One connected
miniature clay world floating in a plain solid [BG_HEX] void — empty backdrop, no sky,
no clouds — seamless flowing aerial transition. [STYLE tail + PALETTE]. Smooth
graceful slow motion. No text, no captions.
```

For the last connector into a hero-product finale: "…glides forward and the world
dissolves toward a single giant [PRODUCT] floating in soft [BG] space, arriving in front
of it."

seedance: `--mode std --resolution 1080p --aspect_ratio 16:9 --duration 5`; kling3_0:
`--mode std --sound off --aspect_ratio 16:9 --duration 5`. Connectors need `--end-image`
→ use a roster model that accepts it (Step 4).

## Copy per section (for the engine config)

- `eyebrow` — 2–4 words, uppercase feel (a value-prop label).
- `title` — 3–6 words, the beat's headline. First section = the site's hero line; last =
  the payoff + it carries the CTA.
- `body` — one sentence, plain-spoken, from the visitor's side.
- `tags` — 0–3 short proof chips (e.g. "Fresh-cooked", "30-min delivery").
